from enum import IntEnum, StrEnum, auto


class PreparingType(IntEnum):
    RECURSIVE = auto()
    DIRECT = auto()


